package com.example.seamsee;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private InputStream inputStream ;
    private TextView counter;
    private ArrayList<String> precictionList;
    private int predictionNumber;
    private Button button;
    private SensorManager sensorManager;
    private int shakeCount=0,shakeCounter=99;
    private boolean isFirstime;
    private float accelCurrent;
    private float accelLast;
    private float threshold = 2f;
    private float shake=0.00f;
    private ImageView siamsee;
    private TextView counter2;
    private Animation animation;
    private Intent intent;
    Handler hdr = new Handler();
    private static final int POLL_INTERVAL = 500;
    private SensorInfo sensor_info = new SensorInfo();
    private SensorInfo previous_sensor_info = new SensorInfo();
    private boolean isDialogOn =false;
    private Runnable pollTask = new Runnable() {
        public void run() {
            showdialog();
            hdr.postDelayed(pollTask, POLL_INTERVAL);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(MainActivity.this,MainActivity2.class);
        inputStream = getResources().openRawResource(R.raw.prediction);
        precictionList = new ArrayList<>();

        isFirstime = true;
        siamsee = findViewById(R.id.siemseeImage);
        try {
            ReadFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.shake);
        shakeCounter = 1;
        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        predictionNumber = getRandom(precictionList.size());
        accelCurrent = SensorManager.GRAVITY_EARTH;
        accelLast = SensorManager.GRAVITY_EARTH;

    }
    public void onAccuracyChanged(Sensor sensor, int accuracy){}
    public void onSensorChanged(SensorEvent event){
        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
//            sensor_info.accX=event.values[0];
//            sensor_info.accY=event.values[1];
//            sensor_info.accZ=event.values[2];
            x = event.values[0];
            y = event.values[1];
            z = event.values[2];
//            accelLast = accelCurrent;
//            accelCurrent = (float)Math.sqrt((double)x*x+y*y+z*z);
        }

    }
    float x,y,z;

    void showdialog(){
        accelLast = accelCurrent;
        accelCurrent = (float)Math.sqrt((double)x*x+y*y+z*z);
        float delta = accelCurrent-accelLast;
        shake = shake*0.9f+delta;
        Log.d("Test","shake "+shake +"threshold "+ threshold);
        Log.d("Test","shake "+(shake>threshold));
        Log.d("Test","count "+shakeCount+" counter "+shakeCounter+"predNum "+predictionNumber+" "+ isFirstime);
        if(shake>threshold){
            shakeCount++;
            siamsee.startAnimation(animation);
        }

        if(shakeCount==shakeCounter&&isFirstime){
            Log.d("Test","count "+shakeCount+" counter "+shakeCounter+"count "+shakeCounter+"");
            if(isFirstime&&!isDialogOn){
                isFirstime=false;
                shakeCount=0;
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(400);
                final AlertDialog.Builder viewDialog = new AlertDialog.Builder(this);
                viewDialog.setIcon(R.drawable.seamsee);
                viewDialog.setTitle("คำทำนายที่ "+predictionNumber);
                viewDialog.setMessage(precictionList.get(predictionNumber));

                viewDialog.setCancelable(false);
                viewDialog.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();

                                isFirstime = true;
                                shakeCount=0;
                                isDialogOn = false;
                            }
                        });
                viewDialog.show();
                isDialogOn = true;
                isFirstime = true;
                shakeCount=0;
                predictionNumber = getRandom(precictionList.size());
                shakeCounter = 1;
                Log.d("Test","count "+shakeCounter);
            }
//            Log.d("Test","count "+shakeCount+" counter "+shakeCounter);
//            predictionNumber = getRandom(precictionList.size());
//            intent.putExtra("prediction",precictionList.get(35));
//            intent.putExtra("index",""+(predictionNumber+1));
//            startActivity(intent);
//            finish();

        }
    }
    void GetPredictState(){
        predictionNumber = getRandom(precictionList.size());
        Intent intent = new Intent(MainActivity.this,MainActivity2.class);
        intent.putExtra("prediction",precictionList.get(35));
        intent.putExtra("index",""+(predictionNumber+1));
        startActivity(intent);
        finish();
    }
    void ReadFile() throws IOException {
        BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(inputStream));
        try {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                precictionList.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            bufferedReader.close();
        }
    }
    int getRandom(int length){
        return new Random().nextInt(length);
    }
    @Override
    public void onBackPressed() {
           shakeCount=0;
           isFirstime = true;
    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                ,SensorManager.SENSOR_DELAY_NORMAL);
        hdr.postDelayed(pollTask, POLL_INTERVAL);
    }
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    static class SensorInfo{
        float accX, accY, accZ;
    }
}