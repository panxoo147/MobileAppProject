package com.example.seamsee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private TextView number;
    private TextView predict;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        number = findViewById(R.id.PredictionNumber);
        predict = findViewById(R.id.PredictionText);
        back = findViewById(R.id.back);

        String pred = getIntent().getStringExtra("prediction");
        String index = getIntent().getStringExtra("index");

        number.setText(index+"");
        predict.setText(pred);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        // your code.
        Intent intent = new Intent(MainActivity2.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}